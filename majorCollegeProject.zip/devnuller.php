<?php
	error_reporting(0);
	file_put_contents('dev2switch.txt',"");
?>
