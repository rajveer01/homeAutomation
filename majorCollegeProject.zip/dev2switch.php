<?php
	error_reporting(0);
	echo file_get_contents('dev2switch.txt');
?>